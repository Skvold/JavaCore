package HW1;

public interface CanRun {
    int run();
}
