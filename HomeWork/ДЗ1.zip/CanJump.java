package HW1;

public interface CanJump {
    int jump();
}
