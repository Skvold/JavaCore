package HW2;

public class MyArrayDataException extends RuntimeException {
    public MyArrayDataException() {
        super();
    }

    public MyArrayDataException(String message) {
        super(message);
    }
}
