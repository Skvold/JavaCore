package HW3;

public class Apple extends Fruit {

    public Apple() {
        super(1.8f);
    }
}
