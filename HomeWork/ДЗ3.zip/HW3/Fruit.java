package HW3;

abstract public class Fruit {
    private float weight;

    public Fruit(float weight) {
        this.weight = weight;
    }
    public float getWeight (){
        return weight;
    }
}
