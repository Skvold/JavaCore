package HW3;

public class Orange extends Fruit{

    public Orange() {
        super(2.5f);
    }
}
